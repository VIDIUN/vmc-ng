# Reach All-In-One Localization

## Updating en locale

The contents of en.js is copied from the locale part in KMS (see reach dashboard for example).

## Creating new locales

Other locales should follow the same file format,
define an object on page called LOCALE with the same keys and required translations as values.

The file's name should be the locale code with which the texts are used.

## Selecting the locale to use

The locale code used is determined by window.parent.kmc.vars.reach.language.
