/* 
 * Global JS interactions
 */

/**
 * namespace to expose global access.
 * @namespace
 */
var GLOBAL_KMS = GLOBAL_KMS || {};

/**
 * Get the default Ajax timeout.
 * @return {number} The default timeout or an overridden value.
 */
function getAjaxTimeout() {
    return GLOBAL_KMS.ajaxTimeout || 60;
}

// disable cache for Ajax calls
$.ajaxSetup({ cache: false });
// hack for IE7
if (!window.console) {
    console = {
        log: function() {}
    };
}

GLOBAL_KMS.helpers = {
    /**
     * Debounce function, taken directly from lodash (thank you)
     * @param func - the callback
     * @param wait - how much time to wait before calling the callback.
     * @param immediate - leading edge - trigger the callback right away and then wait.
     * @returns {Function}
     */
    debounce: function(func, wait, immediate) {
        var timeout;
        return function() {
            var context = this,
                args = arguments,
                later = function() {
                    timeout = null;
                    if (!immediate) func.apply(context, args);
                },
                callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
            if (callNow) func.apply(context, args);
        };
    },
    now:
        Date.now ||
        function() {
            return new Date().getTime();
        },

    /**
     * Throttle function (taken from underscore)
     * Information on the differences between:
     * https://css-tricks.com/debouncing-throttling-explained-examples/
     * @param func
     * @param wait
     * @param options
     * @returns {function}
     */
    throttle: function(func, wait, options) {
        var timeout,
            context,
            args,
            result,
            previous = 0;

        if (!options) options = {};

        var later = function() {
            previous = options.leading === false ? 0 : GLOBAL_KMS.helpers.now();
            timeout = null;
            result = func.apply(context, args);
            if (!timeout) context = args = null;
        };

        var throttled = function() {
            var now = GLOBAL_KMS.helpers.now();
            if (!previous && options.leading === false) previous = now;
            var remaining = wait - (now - previous);
            context = this;
            args = arguments;
            if (remaining <= 0 || remaining > wait) {
                if (timeout) {
                    clearTimeout(timeout);
                    timeout = null;
                }
                previous = now;
                result = func.apply(context, args);
                if (!timeout) context = args = null;
            } else if (!timeout && options.trailing !== false) {
                timeout = setTimeout(later, remaining);
            }
            return result;
        };

        throttled.cancel = function() {
            clearTimeout(timeout);
            previous = 0;
            timeout = context = args = null;
        };

        return throttled;
    }
};

// fix select2 for native:
if (typeof window.select2InputWidth == "undefined") {
    window.select2InputWidth = 10;
}

var historyEnabled = false; // disable by default
// initialize history plugin (disabled by default)
if (historyEnabled == true && typeof history.replaceState != "undefined") {
    var stateObj = {
        link: document.location.href,
        obj: null
    };
    //  add a stateObj to the history entry of the current page view
    history.replaceState(stateObj, document.title, document.location.href);
    // bind the popstate event (catch back and forward actions)
    $(window).bind("popstate", function() {
        // in case the history entry has a stateObj
        if ("state" in window.history) {
            var state = window.history["state"];
            if ("link" in state) {
                var href = state["link"];
                href += "?format=ajax";
                $.getJSON(href, asyncCallback).fail(transportError);
                $("a").removeClass("active");
                $elem.addClass("active");
                doAjaxSpin();
                ajaxRequestInProgress = true;
                if ("obj" in state && state["obj"] != null) {
                    state["obj"].addClass("active");
                }
            }
        }
    });
}

$(document).on("submit", "form", function(event) {
    var $form = $(this);
    return kmsSendAjaxForm($form, event);
});
/**
 * function send form as ajax request with format=ajax
 * if form has ajax=1 attribute
 * preventing any other form submition function
 * if event is sent
 *
 *
 * @param $form
 * @param event
 * @returns {boolean}
 */
function kmsSendAjaxForm($form, event) {
    if ($form.attr("ajax")) {
        doAjaxSpin();
        // async request with post data
        var action = $form.attr("action") + "?format=ajax" + parseLinkParams($(this));
        var $submitBtn = $form.find('input[type="submit"], button[type="submit"]');
        $submitBtn.kmsDisabled();
        var postData = $form.serialize();
        /** workaround max_input_vars limit by encoding entire form into a single base64 POST param **/
        if ($form.attr("context") && $form.attr("context") == "admin") {
            // do the override only for browsers that support it. IE9 for example does not support, so we do not change the post data
            if (window.btoa) {
                postData = "kmsafd=" + encodeURIComponent(btoa($($form).serialize()));
            }
        }
        $.ajax({
            url: action,
            dataType: "json",
            type: $form.attr("method") ? $form.attr("method") : "GET",
            data: postData,
            success: function(data) {
                $submitBtn.kmsDisabled();
                asyncCallback(data);
            },
            fail: transportError
        });
        //$('a').removeClass('active');
        $form.addClass("active");
        if (event) {
            event.stopPropagation();
            event.preventDefault();
        }
        return false;
    }
}

$("html").click(function(event) {
    var $elem = $(event.target);
    // check if target is a button
    if (!$elem.is("button")) {
        // if not, check for closest link
        var $link = $(event.target).closest("a");
        if ($link.is("a")) {
            $elem = $link;
        } else {
            // no link, check for closest button
            $elem = $(event.target).closest("button");
            if (!$elem.is("button")) {
                // target has no link or button
                return;
            }
        }
        $link = null;
    } else {
        // for a inside btn
        var $link = $(event.target).find("a");
        if ($link.is("a")) {
            $elem = $link;
        }
    }

    // if a link is disabled, we don't want to do anything.
    if ($elem.hasClass("disabled")) {
        event.preventDefault();
        return;
    }

    // in case of ctrl click or shift click, we open in new tab/window
    if (event.ctrlKey || event.shiftKey) {
        return;
    }
    var href = $elem.attr("href");
    var rel = $elem.attr("rel");
    var setUrl = $elem.attr("seturl");
    var timeout = $elem.attr("data-timeout");

    if (timeout) {
        setAjaxTimeout(timeout);
    }

    // if the link has a conditional element, call it
    var callback = $elem.attr("data-cond");
    if (callback) {
        var res = new Function("return " + callback)();
        if (!res) {
            return false;
        }
    }

    if (rel) {
        // capture event
        if (ajaxRequestInProgress) {
            return false;
        }

        switch (rel) {
            case "async":
                // check if we modify browser history (html5 browsers)
                if (typeof history.pushState != "undefined" && historyEnabled == true) {
                    // set state obj
                    var stateObj = {
                        link: href,
                        obj: $elem
                    };
                    // modify history
                    if (setUrl === "1") {
                        // if the link needs to set the href in the browser
                        history.pushState(stateObj, $elem.attr("title"), href);
                    } else {
                        // if not, then we put the current location in the browser (leave as is)
                        history.pushState(stateObj, $elem.attr("title"), document.location.href);
                    }
                }
                // add bulk data
                var bulk = $elem.attr("data-bulk-param");
                if (bulk) {
                    data = bulk + "=" + $().kmsCheckAllTable.bulkData();
                }
                href = addQueryDelimiter(href, "ajax") + parseLinkParams($elem);
                doAjaxSpin();
                $elem.addClass("active");

                if (bulk) {
                    $.post(
                        href,
                        data,
                        function(data) {
                            asyncCallback(data);
                        },
                        "json"
                    ).fail(transportError);
                } else {
                    $.getJSON(href, function(data) {
                        asyncCallback(data);
                    }).fail(transportError);
                }
                break;
            case "script":
                href += "?format=script" + parseLinkParams($elem);
                $.getScript(href, scriptCallback).fail(transportError);
                break;
            case "dialog":
                doAjaxSpin();
                // add bulk data
                var bulk = $elem.attr("data-bulk-param");
                if (bulk) {
                    data = bulk + "=" + $().kmsCheckAllTable.bulkData();
                }
                href = addQueryDelimiter(href, "dialog") + parseLinkParams($elem);
                //$.getScript(href, scriptCallback).error(transportError);
                if (bulk) {
                    $.post(href, data, scriptCallback, "script").fail(transportError);
                } else {
                    $.getScript(href, scriptCallback).fail(transportError);
                }

                //mark the element as the active dialog
                $elem.addClass("activeModal");

                break;
            case "require-flash":
                if (!kSupportsFlash()) {
                    alert(translate("Sorry, this action requires Adobe Flash."));
                    return false;
                }
                return true;
                break;
            default:
                return;
        }
        ajaxRequestInProgress = true;
    } else {
        // continue with normal event
        return;
    }

    $elem.removeClass("active");

    event.stopPropagation();
    event.preventDefault();
});

addQueryDelimiter = function(href, type) {
    var delimiter = "?";
    if (href.indexOf(delimiter) !== -1) delimiter = "&";
    href += delimiter + "format=" + type;
    return href;
};

parseLinkParams = function(obj) {
    var data = obj.data("gparams-update");
    if (data) {
        $.each(data, function(key, value) {
            globalParameters.setData(key, value);
        });
    }

    if (typeof globalParameters !== "undefined") {
        var globalPrams = globalParameters.getData();
    }
    var params = obj.attr("data-params");
    return (params ? "&" + params : "") + (globalPrams ? "&" + globalPrams : "");
};

transportError = function(data) {
    setAjaxTimeout(getAjaxTimeout());
    var title, errorDesc;
    ajaxRequestInProgress = false;
    //$('body').removeClass('cursorwait');
    doAjaxUnspin();
    if (data) {
        if (data.statusText == "timeout") {
            title = "Request timeout";
            errorDesc = "Request took too long to complete";
        } else if (data.status == 0 && data.statusText == "error" && data.responseText == "") {
            // do nothing
        } else if (data.status == "405") {
            // try to remove the navigate away confirmation
            try {
                setConfirmUnload(false);
            } catch (e) {}
            // redirect to login
            document.location.href = baseUrl + "/user/login";
            //            $.getScript(baseUrl + '/user/login?format=dialog');
        } else {
            title = data.status != "200" ? "Error : " + data.status : false;
            errorDesc = data.responseText;
        }

        if (title) {
            bootbox.dialog(errorDesc, [{ label: "Close" }], { header: title });
        }
    }
};

function asyncCallback(data) {
    setAjaxTimeout(getAjaxTimeout());
    ajaxRequestInProgress = false;
    var action, content, target, script;
    doAjaxUnspin();
    $(data).kmsInitDisable();

    try {
        if (data && data.content) {
            for (var i = 0; i < data.content.length; i++) {
                action = data.content[i].action;
                content =
                    typeof data.content[i].content != undefined ? data.content[i].content : "";
                target = data.content[i].target;

                if (action && target) {
                    var debugColor = "#ffff99";
                    var debugParent = false;
                    switch (action) {
                        case "replace":
                            $(target).html(content);
                            break;
                        case "replaceWith":
                            $(target).replaceWith(content);
                            break;
                        case "replaceFade":
                            $(target).html(
                                $(content)
                                    .hide()
                                    .fadeIn("slow")
                            );
                            break;
                        case "append":
                            debugColor = "#aaaaff";
                            debugParent = true;

                            $(target).append(content);
                            break;
                        case "appendFade":
                            debugColor = "#aaaaff";
                            debugParent = true;
                            $(target).append(
                                $(content)
                                    .hide()
                                    .fadeIn("fast")
                            );
                            break;
                        case "prepend":
                            debugColor = "#aaaaff";
                            debugParent = true;
                            $(target).prepend(content);
                            break;
                        case "prependFade":
                            debugColor = "#aaaaff";
                            debugParent = true;
                            $(target).prepend(
                                $(content)
                                    .hide()
                                    .fadeIn("fast")
                            );
                            break;
                        case "value":
                            $(target).val(content);
                            break;
                        case "after":
                            debugColor = "#aaaaff";
                            debugParent = true;
                            $(target).after(content);
                            break;
                        case "before":
                            debugColor = "#aaaaff";
                            debugParent = true;
                            $(target).before(content);
                            break;
                        case "afterFade":
                            debugColor = "#aaaaff";
                            debugParent = true;
                            $(target).after(
                                $(content)
                                    .hide()
                                    .fadeIn("fast")
                            );
                            break;
                        case "beforeFade":
                            debugColor = "#aaaaff";
                            debugParent = true;
                            $(target).before(
                                $(content)
                                    .hide()
                                    .fadeIn("fast")
                            );
                            break;
                        case "delete":
                            debugColor = "#ffaaaa";
                            debugParent = true;
                            $(target).remove();
                            break;
                        case "deleteFade":
                            debugColor = "#ffaaaa";
                            debugParent = true;
                            $(target).fadeOut("fast", function() {
                                $(this).remove();
                            });
                            break;
                        case "empty":
                            debugColor = "#ffaaaa";
                            $(target).empty();
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        if (data && data.script) {
            script = data.script;
            eval(script);
        }
    } catch (e) {
        debugger;
    }
}

scriptCallback = function(data) {
    ajaxRequestInProgress = false;
    $("body").removeClass("cursorwait");
    setAjaxTimeout(getAjaxTimeout());
    doAjaxUnspin();
};

/**
 *
 * translation function
 * expects translation string key (the string to translate)
 * and an array of args for placeholders replacements
 * e.g - translate('there are %1 cats and %2 dogs...', array(3, 5))
 * @param string to be translated
 * @param args for placeholders replacement
 */
function translate(string, args) {
    return typeof LOCALE !== "undefined" && LOCALE[string]
        ? replacePlaceholders(LOCALE[string], args)
        : string;
}

/**
 * translate with the option for singular/plural.
 * usage example:
 * translate('%1 Entry Found', '%1 Entries Found', [ 22 ]) will output "22 Entries Found"
 * (Don't forget to add the translations to the LOCALE using the jsTranslations partial!)
 * @param singularString
 * @param pluralString
 * @param args
 * @returns string
 */
function translatePlural(singularString, pluralString, args) {
    var plural = false;
    if (!isNaN(args[0])) {
        plural = args[0] > 1 || args[0] === 0;
    }

    return plural ? translate(pluralString, args) : translate(singularString, args);
}

/**
 * replacement of placeholders in a string (%1 %2 .... %n)
 * @param string
 * @param args for placeholders replacement
 */
function replacePlaceholders(string, args) {
    if (args != null && typeof args != "undefined" && args.length > 0) {
        //translation placeholders (%1 %2 ... %n)
        var regEx = /(%[1-9]?[0-9])/g;
        var placeholders = string.match(regEx);
        while (placeholders.length > 0) {
            string = string.replace(placeholders.shift(), args.shift());
        }
    }
    return string;
}

/**
 * flash detection
 */
function kSupportsFlash() {
    var version = kGetFlashVersion()
        .split(",")
        .shift();
    if (version < 10) {
        return false;
    } else {
        return true;
    }
}

function kGetFlashVersion() {
    // navigator browsers:
    if (navigator.plugins && navigator.plugins.length) {
        try {
            if (navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin) {
                return (
                    navigator.plugins["Shockwave Flash 2.0"] || navigator.plugins["Shockwave Flash"]
                ).description
                    .replace(/\D+/g, ",")
                    .match(/^,?(.+),?$/)[1];
            }
        } catch (e) {}
    }
    // IE
    try {
        try {
            if (typeof ActiveXObject != "undefined") {
                // avoid fp6 minor version lookup issues
                // see: http://blog.deconcept.com/2006/01/11/getvariable-setvariable-crash-internet-explorer-flash-6/
                var axo = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");
                try {
                    axo.AllowScriptAccess = "always";
                } catch (e) {
                    return "6,0,0";
                }
            }
        } catch (e) {}
        return new ActiveXObject("ShockwaveFlash.ShockwaveFlash")
            .GetVariable("$version")
            .replace(/\D+/g, ",")
            .match(/^,?(.+),?$/)[1];
    } catch (e) {}
    return "0,0,0";
}

/**
 * set an interval of 5 minutes to ping the keep alive action (for extending the session)
 **/
// interval in minutes
var keepAliveInterval;
function enableKeepAlive(interval) {
    // default is 5 minutes
    var delay = 5 * 60 * 1000;
    if (interval) {
        delay = interval * 60 * 1000;
    }

    keepAliveInterval = setInterval(function() {
        $.ajax({
            url: baseUrl + "/user/keep-alive",
            type: "POST",
            error: transportError
        });
    }, delay);
}

function setAjaxTimeout(timeout) {
    $.ajaxSetup({
        timeout: timeout * 1000
    });
}

/**
 *  fetch content in async manner, and replaces the specified target (first target only)
 */
function getAsyncContent(url, target, triggerEvent, eventElement, multi, spinnerType) {
    //$(eventElement).off(triggerEvent); //we shouldn't remove other triggers. this was due to double js triggering, shouldn't occur anymore 22.9.13 Nadav S & Rotem A

    if (multi) {
        // run on every occurence of the event
        $("html").on(triggerEvent, eventElement, function(event) {
            asyncContent(url, target, triggerEvent, eventElement, spinnerType);
        });
    } else {
        // ron only on the first event occurence
        $("html").one(triggerEvent, eventElement, function(event) {
            asyncContent(url, target, triggerEvent, eventElement, spinnerType);
        });
    }

    function asyncContent(url, target, triggerEvent, eventElement, spinnerType) {
        // mark url as ajax
        url += "?format=ajax";

        if (typeof globalParameters !== "undefined") {
            var globalPrams = globalParameters.getData();
            if (globalPrams) {
                url += "&" + globalPrams;
            }
        }

        // add bulk data if exists
        var bulk = $(eventElement).attr("data-bulk-param");
        if (bulk) {
            data = bulk + "=" + $().kmsCheckAllTable.bulkData();
        }

        var smallSpinner;
        if (spinnerType == "small") {
            smallSpinner = elementSpin(target);
        } else {
            doAjaxSpin();
        }

        if (bulk) {
            // bulk actions contain lots of data - use post
            $.post(url, data, callback, "json").fail(transportError);
        } else {
            // the rest can use get
            $.getJSON(url, callback).fail(transportError);
        }

        function callback(data) {
            if (data && data.content && target) {
                data.content[0].target = target;
                data.content[0].action = "replace";
            }
            asyncCallback(data);
            if (smallSpinner != null) {
                smallSpinner.stop();
            }
        }
    }
}

setAjaxTimeout(getAjaxTimeout());
var ajaxRequestInProgress = false;

/**
 *  prototype to hold global paramaters for async requests
 */
GlobalParametersPrototype = function() {
    this.data = {};

    this.getData = function(param) {
        if (param) {
            return this.data[param];
        } else {
            return jQuery.param(this.data);
        }
    };

    this.clearData = function() {
        this.data = {};
    };

    this.setData = function(param, value) {
        this.data[param] = value;
    };
};

var globalParameters = new GlobalParametersPrototype();

/**
 *  prototype to hold an endless scroller
 */
EndlessScrollerPrototype = function(id, url, postData) {
    this.page = 1;
    this.active = true;
    this.url = null;
    this.id = id;
    this.message = "";
    this.postData = postData;
    if (url.length > 0) {
        this.url = url;
    } else {
        this.url = document.URL;
    }
    this.url = this.url.replace(/#$/);

    this.reset = function(url) {
        this.url = url;
        this.page = 1;
        this.active = true;
    };

    this.stop = function(message) {
        this.active = false;
        this.message = message;
    };
};

/**
 *  holds all endless scrollers, and activate the right one
 */
EndlessScrollersPrototype = function() {
    this.scrollers = {};
    this.active = false;
    this.fetching = false;
    this.message = null;
    this.manualMode = false;

    this.setScroller = function(id, url, postData, element) {
        this.scrollers[id] = new EndlessScrollerPrototype(id, url, postData);
        endlessScrollersPrototype.activate(element, id);
    };

    this.stopScoller = function(id, message, showMessageNow) {
        var scroller = this.getScroller(id);
        scroller.stop(message);
        if (showMessageNow) {
            $("#" + scroller.id).empty();
            this.showMessage(null, scroller);
        }
    };

    this.getScroller = function(id) {
        return this.scrollers[id];
    };

    this.hasScrollers = function() {
        return $().assocArraySize(this.scrollers) > 0;
    };

    this.getVisibleScroller = function(element) {
        var scrollerId = null;
        var scroller = null;

        if (endlessScrollersPrototype.manualMode && typeof element != "undefined") {
            scrollerId = element;
        } else {
            if (typeof element == "undefined" || element == window) {
                element = "body";
            }
            scrollerId = $(".endlessScroll", element)
                .filter(":visible")
                .attr("id");
        }

        if (scrollerId) {
            scroller = endlessScrollersPrototype.getScroller(scrollerId);
        }

        return scroller;
    };

    this.showMessage = function(element, scroller) {
        var scroller = scroller || endlessScrollersPrototype.getVisibleScroller(element);

        // prevent duplicate messages appearing
        $(".alert.alert-info").each(function() {
            if ($(this).text() == scroller.message) {
                $(this).remove();
            }
        });
        $("#" + scroller.id).after(
            '<div id="' +
                scroller.id +
                '_scroller_alert" class="alert alert-info endlessScrollAlert">' +
                scroller.message +
                "</div>"
        );
    };

    this.setManualMode = function() {
        this.manualMode = true;
    };

    this.addManualModeButton = function(scrollerId) {
        if ($("#" + scrollerId + " .endless-scroll-more").length == 0) {
            $("#" + scrollerId + ".endlessScroll").html(
                "" +
                    '<div class="endless-scroll-more">' +
                    "<a href=\"javascript:endlessScrollersPrototype.loadNextPage('" +
                    scrollerId +
                    '\');" class="btn">' +
                    "&nbsp;" +
                    translate("Load More") +
                    "</a>" +
                    "</div>" +
                    ""
            );
        }
    };

    this.activate = function(element, id) {
        if (endlessScrollersPrototype.manualMode) {
            this.active = true;
            var waitForScroller = function() {
                var scroller = endlessScrollersPrototype.getScroller(id);
                if (scroller) {
                    endlessScrollersPrototype.addManualModeButton(scroller.id);
                } else {
                    setTimeout(waitForScroller, 100);
                }
            };
            waitForScroller();
        } else if (!this.active || typeof element != "undefined") {
            this.active = true;
            if ($("html").hasClass("ie7")) {
                $("body").scroll(function() {
                    scrollCallBack("body");
                });
            } else {
                if (typeof element == "undefined") {
                    var element = window;
                }

                $(element).scroll(function() {
                    scrollCallBack(element);
                });
            }
        }
    };

    this.loadNextPage = function(id) {
        scrollCallBack(id, true);
    };

    this.reloadLastPage = function(script) {
        var scroller = endlessScrollersPrototype.getVisibleScroller();
        if (scroller && scroller.active) {
            endlessScrollersPrototype.fetching = true;

            var url = scroller.url + "?format=ajax&loadone=1";
            if (url.indexOf("page=") > 0) {
                url = url.replace("/[&|?]page=(.*)/", scroller.page);
            } else if (url.indexOf("/page/") > 0) {
                url = url.replace("/page/(d+)/", scroller.page);
            } else {
                url += "&page=" + scroller.page;
            }

            function callback(data) {
                if (script) {
                    eval(script);
                }
                asyncCallback(data);
            }

            if (
                scroller.postData != null &&
                scroller.postData != undefined &&
                scroller.postData != ""
            ) {
                $.post(url, scroller.postData, callback, "json").fail(transportError);
            } else $.getJSON(url, callback).fail(transportError);
        } else {
            if (script) {
                eval(script);
            }
        }
    };

    $(document).ready(function() {
        if (endlessScrollersPrototype.manualMode || endlessScrollersPrototype.hasScrollers()) {
            endlessScrollersPrototype.activate();
        }
    });

    function scrollCallBack(element, force) {
        var scrollSpinner = null;

        if (element == window || element == document || typeof element == "undefined") {
            var element = window;
            var docheight = $(document).height();
        } else {
            var docheight = $(element)
                .children()
                .height();
        }

        //fire a scroll start event on this element
        $(element).trigger("endless.scroll.start");
        if (!endlessScrollersPrototype.fetching) {
            if (!force) {
                // trigger for hosted and custom themes with no footer
                var wintop = $(element).scrollTop(),
                    winheight = $(element).height();
                var scrolltrigger = 0.87;

                // trigger for large footers
                var docViewBottom = wintop + winheight;
                var elemTop = docViewBottom;
                if (typeof $("#footer").offset() != "undefined" && element == window) {
                    elemTop = $("#footer").offset().top + 60;
                }
            }
            if (
                elemTop < docViewBottom ||
                (wintop + winheight) / docheight > scrolltrigger ||
                force
            ) {
                // get the relevant(visible) scroller
                var scroller = endlessScrollersPrototype.getVisibleScroller(element);

                if (scroller && scroller.active) {
                    endlessScrollersPrototype.fetching = true;

                    scroller.page += 1;
                    var url = scroller.url + "?format=ajax";
                    if (url.indexOf("page=") > 0) {
                        url = url.replace("/[&|?]page=(.*)/", scroller.page);
                    } else if (url.indexOf("/page/") > 0) {
                        url = url.replace("/page/(d+)/", scroller.page);
                    } else {
                        url += "&page=" + scroller.page;
                    }

                    if (typeof globalParameters !== "undefined") {
                        var globalPrams = globalParameters.getData();
                        if (globalPrams) {
                            url += "&" + globalPrams;
                        }
                    }

                    scrollSpinner = elementSpin($("#" + scroller.id));

                    if (endlessScrollersPrototype.manualMode) {
                        $("#" + scroller.id + " .endless-scroll-more").hide();
                    }

                    if (
                        scroller.postData != null &&
                        scroller.postData != undefined &&
                        scroller.postData != ""
                    ) {
                        $.post(url, scroller.postData, callback, "json").fail(transportError);
                    } else {
                        $.getJSON(url, callback).fail(transportError);
                    }
                }
            }
        }

        function callback(data) {
            var showMessage = false;

            if (data && data.content) {
                data.content[0].action = "append";
            } else {
                // show no nore data message
                showMessage = true;
            }

            endlessScrollersPrototype.fetching = false;
            scrollSpinner.stop();
            scrollSpinner = null;
            asyncCallback(data);
            //fire a scroll end event with its' data
            $(element).trigger("endless.scroll.end", { scrollData: data });
            if (showMessage) {
                endlessScrollersPrototype.showMessage(element);
            } else if (endlessScrollersPrototype.manualMode) {
                $("#" + scroller.id + " .endless-scroll-more").show();
            }
        }
    }
};

var endlessScrollersPrototype = new EndlessScrollersPrototype();

function startEndlessScroller(id, url, postData, element) {
    endlessScrollersPrototype.setScroller(id, url, postData, element);
}

function stopEndlessScroller(id, message, showMessageNow) {
    showMessageNow = false || showMessageNow;
    endlessScrollersPrototype.stopScoller(id, message, showMessageNow);
}

function reloadLastPage(script) {
    endlessScrollersPrototype.reloadLastPage(script);
}

/**
 *  get data from kms, using the kms callbacks
 */
function getDataFromKms(url, data, success, spin, error) {
    var errorCallback = error ? error : transportError;

    // add the script param
    data["format"] = "script";

    if (spin) {
        doAjaxSpin();
    }
    $.getJSON(url, data, callback).fail(errorCallback);

    function callback(data) {
        if (spin) {
            doAjaxUnspin();
        }
        success(data);
    }
}

/**
 *  get data from kms, using the kms ajax callbacks
 */
function sendDataToKms(url, data, spin, error) {
    var errorCallback = error ? error : transportError;

    // add the script param
    data["format"] = "script";

    if (spin) {
        doAjaxSpin();
    }
    $.getJSON(url, data, callback).fail(errorCallback);

    function callback(data) {
        asyncCallback(data);
    }
}

/**
 * logger function
 */
function jsLog(object) {
    if (typeof console != "undefined" && console && console.log) {
        console.log(object);
    }
}

/**
 *  KMS analytics events
 */
if (typeof Kms_Analytics_Active !== "undefined" && Kms_Analytics_Active) {
    $(document).ready(function() {
        $(document).on("submit", "[data-track]", function(event) {
            $(this).trigger("kmsTrack", $(this).attr("data-track"));
        });
        $("html").on("click", "[data-track]:not(form,input)", function(event) {
            $(this).trigger("kmsTrack", $(this).attr("data-track"));
        });
    });
}

/** detect device */
function getBootstrapDeviceSize() {
    var envs = ["phone", "tablet", "desktop"];
    var $el = $("<div>");
    $el.appendTo($("body"));
    for (var i = envs.length - 1; i >= 0; i--) {
        var env = envs[i];
        $el.addClass("hidden-" + env);
        if ($el.is(":hidden")) {
            $el.remove();
            return env;
        }
    }
    return "desktop";
}
